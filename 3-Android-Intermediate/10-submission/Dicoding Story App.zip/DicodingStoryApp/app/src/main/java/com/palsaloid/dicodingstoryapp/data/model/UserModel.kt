package com.palsaloid.dicodingstoryapp.data.model

data class UserModel (
    val name: String,
    val token: String,
    val isLogin: Boolean
)
