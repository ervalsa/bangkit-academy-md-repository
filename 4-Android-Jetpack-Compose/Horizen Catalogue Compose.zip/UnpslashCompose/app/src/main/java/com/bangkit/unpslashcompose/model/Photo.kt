package com.bangkit.unpslashcompose.model

data class Photo(
    val id: Long,
    val imageUrl: Int,
    val name: String,
    val etalase: String,
    val description: String
)