package com.bangkit.unpslashcompose.ui.screen.splash

import androidx.compose.runtime.Composable

@Composable
fun SplashScreen() {

}