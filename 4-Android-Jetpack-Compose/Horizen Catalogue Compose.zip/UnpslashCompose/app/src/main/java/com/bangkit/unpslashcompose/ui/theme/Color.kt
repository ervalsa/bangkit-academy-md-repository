package com.bangkit.unpslashcompose.ui.theme

import androidx.compose.ui.graphics.Color

val Black = Color(0xFF141414)
val Purple700 = Color(0xFF3700B3)
val Teal200 = Color(0xFF03DAC5)
val DragonFruit = Color(0xFFB2017E)